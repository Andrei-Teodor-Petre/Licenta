//
//  Video.swift
//  VSapp
//
//  Created by Andrei Petre on 07.04.2022.
//

import Foundation




struct PexelsVideo : Identifiable, Decodable{
    var id: Int
    var image: String
    var duration: Int
    var user: User
    var videoFiles: [VideoFile]
    var url: String
    
    init(){
        id = 0
        image = ""
        duration = 0
        user = User()
        videoFiles = []
        url = ""
        
    }
    
    struct User: Identifiable, Decodable{
        var id: Int
        var name: String
        var url: String
        
        init() {
            id = 0
            name = ""
            url = ""
        }
    }
    
    struct VideoFile : Identifiable, Decodable{
        var id: Int
        var quality: String
        var fileType: String
        var link: String
        
        init() {
            id = 0
            quality = ""
            fileType = ""
            link = ""
        }
    }
    
}

struct ResponseBodyVideoSearchPexels: Decodable{
    var page : Int
    var perPage: Int
    var totalResults: Int
    var url: String
    var videos: [PexelsVideo]
}

struct NetworkVideo: Identifiable, Decodable{
    let id: Int
    let url: String
    let thumbnail: String
    let duration: Int
    let user: String
    let tags: [TagKey]
    
    init(){
        id = 0
        url = ""
        thumbnail = ""
        duration = 0
        user = ""
        tags = []
    }
}

struct TagKey: Identifiable, Decodable, Hashable{
    var id: Int
    var value: String
    
    init(){
        id = 0
        value = ""
    }
}



