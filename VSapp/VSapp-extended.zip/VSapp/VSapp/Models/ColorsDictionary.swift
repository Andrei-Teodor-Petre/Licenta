//
//  ColorsDictionary.swift
//  VSapp
//
//  Created by Andrei Petre on 23.04.2022.
//

import Foundation
import SwiftUI

struct ColorConstants {
    //background - tame colors
    static let eggshellColor = Color.init(red: 240, green: 234, blue: 214)


    //accent colors
    static let darkslategray : Color = Color.init(red:8,green:90,blue:92)
    static let darkcyan = Color.init(red:6,green:146,blue:152)
    static let mediumaquamarine = Color.init(red:107, green:189, blue:195)
    static let lightseagreen = Color.init(red:38, green:166, blue:154)
    static let darkpurple = Color.init(red:126, green:111, blue:156)
    static let plum : Color = Color.init(red:193, green:163, blue:208)
}
