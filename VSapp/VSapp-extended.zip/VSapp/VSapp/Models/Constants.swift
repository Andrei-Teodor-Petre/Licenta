//
//  Constants.swift
//  VSapp
//
//  Created by Andrei Petre on 03.06.2022.
//

import Foundation

//84.232.193.57 - local
//192.168.0.183 - macbook
struct Constants{
    let base_url : String = "http://192.168.0.183:5201"
    var dynamic_base_url : String = ""
}
