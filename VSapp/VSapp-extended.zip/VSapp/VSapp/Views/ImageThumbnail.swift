//
//  ImageThumbnail.swift
//  VSapp
//
//  Created by Andrei Petre on 04.06.2022.
//

import SwiftUI

struct ImageThumbnail: View {
    var image: PexelsImage
    var networkImage: NetworkImage
    
    init(fromPexelImage image: PexelsImage ){
        self.image = image
        self.networkImage = NetworkImage()
    }
    
    init(fromNetworkImage network_image: NetworkImage){
        self.image = PexelsImage()
        self.networkImage = network_image
    }
    
    var body: some View {
        ZStack {
            ZStack(alignment: .bottomLeading){
                if self.image.id != 0
                {
                    AsyncImage(url : URL(string: image.src.portrait)){ image in
                        image.resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 140, height: 280)
                            .cornerRadius(30)
                    } placeholder: {
                        Rectangle().foregroundColor(.gray.opacity(0.3))
                            .frame(width: 140, height: 280)
                            .cornerRadius(30)
                    }
                    
                    VStack(alignment: .leading)
                    {
                        Text("\(image.photographer)")
                            .font(.caption).bold()
                        Text("\(image.alt)")
                            .font(.caption).bold()
                            .multilineTextAlignment(.leading)
                    }
                    .foregroundColor(.white)
                    .shadow(radius: 20)
                    .padding()
                }
                
                if self.networkImage.id != 0{
                    AsyncImage(url : URL(string: constants.base_url+networkImage.url)){ image in
                        image.resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 140, height: 280)
                            .cornerRadius(30)
                    } placeholder: {
                        Rectangle().foregroundColor(.gray.opacity(0.3))
                            .frame(width: 140, height: 280)
                            .cornerRadius(30)
                    }
                    
                    VStack(alignment: .leading)
                    {
                        Text("\(networkImage.id)")
                            .font(.caption).bold()
                        Text("\(networkImage.id) sec")
                            .font(.caption).bold()
                            .multilineTextAlignment(.leading)
                    }
                    .foregroundColor(.white)
                    .shadow(radius: 20)
                    .padding()
                }
            }
            .frame(width: 140, height: 280)
            
            Image(systemName: "")
//            Image(systemName: "play.fill")
//                .foregroundColor(.white)
//                .font(.title)
//                .padding()
//                .background(.ultraThinMaterial)
//                .cornerRadius(50)
        }
    }
}

//struct ImageThumbnail_Previews: PreviewProvider {
//    static var previews: some View {
//        ImageThumbnail()
//    }
//}
