//
//  VideoPage.swift
//  VSapp
//
//  Created by Andrei Petre on 26.05.2022.
//

import SwiftUI
import AVKit


struct VideoView: View {
    var video: PexelsVideo
    var networkVideo: NetworkVideo
    @State private var player = AVPlayer()
    
    init(fromPexelVideo video: PexelsVideo ){
        self.video = video
        self.networkVideo = NetworkVideo()
    }
    
    init(fromNetworkVideo apiVideo: NetworkVideo){
        self.video = PexelsVideo()
        self.networkVideo = apiVideo
    }
    
    var body: some View {
        VideoPlayer(player: player)
            .edgesIgnoringSafeArea(.all)
            .onAppear(){
                if let link = video.videoFiles.first?.link{
                    player = AVPlayer(url: URL(string: link)!)
                    player.play()
                }
                
                if networkVideo.id != 0{
                    let link = "\(constants.base_url)\(networkVideo.url)"
                    player = AVPlayer(url: URL(string: link)!)
                    player.play()
                }
            }
    }
}

struct VideoView_Previews: PreviewProvider {
    static var previews: some View {
        VideoView(fromPexelVideo: previewVideo)
    }
}
