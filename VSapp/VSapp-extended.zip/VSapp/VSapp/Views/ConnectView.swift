//
//  ConnectView.swift
//  VSapp
//
//  Created by Andrei Petre on 13.06.2022.
//

import SwiftUI

struct ConnectView: View {
    
    @State private var url: String = ""
    @State private var password: String = ""
    
    var body: some View {
        
        VStack{
            TextField("URL", text: $url).padding()
            TextField("Password", text: $password).padding()
            

            NavigationLink(destination: ContentView(), label: {
                Text("Connect")
                .font(.caption)
                .bold()
                .foregroundColor(.black)
                .padding(10)
                .background(.thickMaterial)
                .cornerRadius(10)
                .onTapGesture {
                    //set the connction string
                    constants.dynamic_base_url = url
                }
            })
            


        }
        //Color("AccentColor").ignoresSafeArea(.all)
        //.background()
    }

}

struct ConnectView_Previews: PreviewProvider {
    static var previews: some View {
        ConnectView()
    }
}
