//
//  UploadView.swift
//  VSapp
//
//  Created by Andrei Petre on 05.06.2022.
//

import SwiftUI

struct UploadView: View {
    
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct UploadView_Previews: PreviewProvider {
    static var previews: some View {
        UploadView()
    }
}
