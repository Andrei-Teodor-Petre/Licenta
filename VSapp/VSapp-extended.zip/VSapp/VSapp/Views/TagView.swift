//
//  TagView.swift
//  VSapp
//
//  Created by Andrei Petre on 23.04.2022.
//

import SwiftUI

struct Tag: View {
    var query: TagKey
    var isSelected: Bool
    
    var body: some View {
        Text(query.value)
            .font(.caption)
            .bold()
            .foregroundColor(isSelected ? .blue : .accentColor)
            .padding(10)
            .background(.thickMaterial)
            .cornerRadius(10)
    }
}

