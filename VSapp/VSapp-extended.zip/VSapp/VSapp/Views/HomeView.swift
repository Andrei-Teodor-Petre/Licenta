//
//  HomeView.swift
//  VSapp
//
//  Created by Andrei Petre on 05.04.2022.
//

import SwiftUI
import AVKit

struct HomeView: View {
    
    // MARK: Colors
    static let darkslategray : Color = Color.init(red:8,green:90,blue:92)
    static let darkcyan = Color.init(red:6,green:146,blue:152)
    static let mediumaquamarine = Color.init(red:107, green:189, blue:195)
    static let lightseagreen = Color.init(red:38, green:166, blue:154)
    static let darkpurple = Color.init(red:126, green:111, blue:156)
    static let plum : Color = Color.init(red:193, green:163, blue:208)
    // MARK: End colors
    
    
    
    private var symbols = ["keyboard", "hifispeaker.fill", "printer.fill", "tv.fill", "desktopcomputer", "headphones", "tv.music.note", "mic", "plus.bubble", "video"]

    
    //darkcyan, mediumaquamarine, lightseagreen, darkpurple, plum
    private var colors: [Color] = [.blue, .green,.cyan, plum]

    private var gridItemLayout = [GridItem(.flexible()), GridItem(.flexible())]
    

    
    var body: some View {
        NavigationView{
            VStack{
                ScrollView {
                    LazyVGrid(columns: gridItemLayout, spacing: 20) {
                        ForEach((0...9999), id: \.self) {
                            ThumbnailView(icon: symbols[$0 % symbols.count], fontSize: 30, frameWidth: 50, frameHeight: 50, cornerRadius: 10, frameColor: colors[$0 % colors.count])
                        }
                    }
                }
            }
            .background(ColorConstants.eggshellColor)
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
