//
//  VideoView.swift
//  VSapp
//
//  Created by Andrei Petre on 05.04.2022.
//

import SwiftUI
import AVKit

var constants = Constants()
let videoUrl = URL(string:"https://www.apple.com/105/media/lae/iphone-se/2022/90024c0f-285a-4bf5-af04-2c38de97b06e/anim/apps/large_2x.mp4")!

//https://images.pexels.com/videos/1448735/free-video-1448735.jpg?fit=crop&w=1200&h=630&auto=compress&cs=tinysrgb

//https://www.eea.europa.eu/themes/biodiversity/state-of-nature-in-the-eu/state-of-nature-2020-subtopic/image_print

struct VideoThumbnail: View {
    
    var video: PexelsVideo
    var networkVideo: NetworkVideo
    
    init(fromPexelVideo video: PexelsVideo ){
        self.video = video
        self.networkVideo = NetworkVideo()
    }
    
    init(fromNetworkVideo apiVideo: NetworkVideo){
        self.video = PexelsVideo()
        self.networkVideo = apiVideo
    }
    
    var body: some View {
        ZStack {
            ZStack(alignment: .bottomLeading){
                if self.video.id != 0
                {
                    AsyncImage(url : URL(string: video.image)){ image in
                        image.resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 140, height: 280)
                            .cornerRadius(30)
                    } placeholder: {
                        Rectangle().foregroundColor(.gray.opacity(0.3))
                            .frame(width: 140, height: 280)
                            .cornerRadius(30)
                    }
                    
                    VStack(alignment: .leading)
                    {
                        Text("\(video.duration) sec")
                            .font(.caption).bold()
                        Text("\(video.user.name) sec")
                            .font(.caption).bold()
                            .multilineTextAlignment(.leading)
                    }
                    .foregroundColor(.white)
                    .shadow(radius: 20)
                    .padding()
                }
                if self.networkVideo.id != 0{
                    AsyncImage(url : URL(string: constants.base_url+networkVideo.thumbnail)){ image in
                        image.resizable()
                            .aspectRatio(contentMode: .fill)
                            .frame(width: 140, height: 280)
                            .cornerRadius(30)
                    } placeholder: {
                        Rectangle().foregroundColor(.gray.opacity(0.3))
                            .frame(width: 140, height: 280)
                            .cornerRadius(30)
                    }
                    
                    VStack(alignment: .leading)
                    {
                        Text("\(networkVideo.duration) sec")
                            .font(.caption).bold()
                        Text("\(networkVideo.user)")
                            .font(.caption).bold()
                            .multilineTextAlignment(.leading)
                    }
                    .foregroundColor(.white)
                    .shadow(radius: 20)
                    .padding()
                }
            }
            .frame(width: 140, height: 280)
            
            Image(systemName: "")
            
            Image(systemName: "play.fill")
                .foregroundColor(.white)
                .font(.title)
                .padding()
                .background(.ultraThinMaterial)
                .cornerRadius(50)
        }
    }
}

struct VideoThumbnail_Previews: PreviewProvider {
    static var previews: some View {
        VideoThumbnail(fromPexelVideo: previewVideo)
    }
}
