//
//  ThumbnailView.swift
//  VSapp
//
//  Created by Andrei Petre on 16.04.2022.
//

import SwiftUI

let preview_frame = "headphones";

let darkslategray : Color = Color.init(red:8,green:90,blue:92)


struct ThumbnailView: View {
    
    var icon: String;
    var fontSize: Int32;
    var frameWidth: Int32;
    var frameHeight: Int32;
    var cornerRadius: Int32;
    var frameColor: Color;
    
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: CGFloat(fontSize)))
            .frame(width: CGFloat(frameWidth), height: CGFloat(frameHeight))
            .foregroundColor(frameColor)
            .cornerRadius(CGFloat(cornerRadius))
            
    }
}

struct ThumbnailView_Previews: PreviewProvider {
    static var previews: some View {
        ThumbnailView(icon: "keyboard", fontSize: 30, frameWidth: 50, frameHeight: 50, cornerRadius: 10, frameColor: darkslategray)
    }
}
