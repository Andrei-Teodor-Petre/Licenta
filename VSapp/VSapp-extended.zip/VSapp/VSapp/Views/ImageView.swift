//
//  ImageView.swift
//  VSapp
//
//  Created by Andrei Petre on 04.06.2022.
//

import SwiftUI

struct ImageView: View {
    
    init(fromPexelImage image: PexelsImage ){
    }
    
    init(fromNetworkImage network_image: NetworkImage){
    }
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

//struct ImageView_Previews: PreviewProvider {
//    static var previews: some View {
//        ImageView()
//    }
//}
