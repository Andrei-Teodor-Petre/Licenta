//
//  ContentView.swift
//  VSapp
//
//  Created by Andrei Petre on 05.04.2022.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var videoManager = VideoManager()
    @StateObject var imageManager = ImageManager()
    @State private var isShowingVideoPicker = false
    
    @State private var isVideoFeed = true
    //@State private var uploadImageUrl : URL
    
    
    
    
    
    var columns = [GridItem(.adaptive(minimum: 160), spacing: 20)]
    
    var body: some View {
        NavigationView {
            VStack{
                ScrollView( .horizontal, showsIndicators: false){
                    HStack{
                        if isVideoFeed{
                            ForEach(videoManager.TagDictionary, id: \.self) {searchQuery in
                                Tag(query: searchQuery, isSelected: videoManager.selctedQuery == searchQuery)
                                .onTapGesture
                                {
                                    videoManager.self.selctedQuery = searchQuery
                                }
                            }
                        }
                        else {
                            ForEach(videoManager.TagDictionary, id: \.self) {searchQuery in
                                Tag(query: searchQuery, isSelected: imageManager.selctedQuery == searchQuery)
                                .onTapGesture
                                {
                                    imageManager.self.selctedQuery = searchQuery
                                }
                            }
                        }

                        
                    }
                    .padding()
                }

        
                ScrollView
                {
                    ///VIDEOS
                    if isVideoFeed{
                        if videoManager.videos.isEmpty && videoManager.api_videos.isEmpty{
                            ProgressView()
                        }
                        else{
//                            if !videoManager.videos.isEmpty && videoManager.self.selctedQuery.value != "network"{
//                                LazyVGrid(columns: columns, spacing: 20){
//                                    ForEach(videoManager.videos, id: \.id){ video in
//                                        NavigationLink{
//                                            VideoView(fromPexelVideo: video)
//                                        } label: {
//                                            VideoThumbnail(fromPexelVideo: video)
//                                        }
//                                    }
//                                }
//                                .padding()
//                            }
                            if !videoManager.api_videos.isEmpty {
                                LazyVGrid(columns: columns, spacing: 20){
                                    ForEach(videoManager.api_videos, id: \.id){ video in
                                        NavigationLink{
                                            VideoView(fromNetworkVideo: video)
                                        } label: {
                                            VideoThumbnail(fromNetworkVideo: video)
                                        }
                                    }
                                }
                                .padding()
                                .refreshable{
                                    print("refreshing")
                                }
                            }
                        }
                    }
                    
                    
                    ///IMAGES
                    else{
                        if imageManager.images.isEmpty && imageManager.network_images.isEmpty{
                            ProgressView()
                        }
                        else{
                            if !imageManager.images.isEmpty{
                                LazyVGrid(columns: columns, spacing: 20){
                                    ForEach(imageManager.images, id: \.id){ image in
                                        NavigationLink{
                                            ImageView(fromPexelImage: image)
                                        } label: {
                                            ImageThumbnail(fromPexelImage: image)
                                        }
                                    }
                                }
                                .padding()
                            }
                            if !imageManager.network_images.isEmpty && imageManager.self.selctedQuery.value == "network"{
                                LazyVGrid(columns: columns, spacing: 20){
                                    ForEach(imageManager.network_images, id: \.id){ image in
                                        NavigationLink{
                                            ImageView(fromNetworkImage: image)
                                        } label: {
                                            ImageThumbnail(fromNetworkImage: image)
                                        }
                                    }
                                }
                                .padding()
                            }
                        }
                    }

                }
                .frame(maxWidth: .infinity)
                .refreshable{
                    print("refreshing")
                }
                
                HStack{
                    //add upload button here
                    Image(systemName: "plus.circle")
                        .foregroundColor(.white)
                        .font(.title)
                        .padding()
                        .background(.ultraThinMaterial)
                        .cornerRadius(50)
                        .onTapGesture {
                            print("open drawer")
                            //here add the open menu for record or chose from lib CHOICE
                            isShowingVideoPicker = true
                        }
                    }

                }
                .background(Color("AccentColor"))
                .navigationBarHidden(true)
                .sheet(isPresented: $isShowingVideoPicker, content: { AssetPicker(videoManager: self.videoManager, imageManager: self.imageManager) } )
        }
    }
    
}
