//
//  VideoPickerSheet.swift
//  VSapp
//
//  Created by Andrei Petre on 01.06.2022.
//

import SwiftUI

struct AssetPicker: UIViewControllerRepresentable{

    //@Binding var refresh : Bool
    @ObservedObject var videoManager: VideoManager
    @ObservedObject var imageManager : ImageManager
    
    //@Binding var selectedImageUrl : URL
    
    let api_wrapper : APICaller = APICaller()
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.mediaTypes = ["public.movie"]
        picker.videoMaximumDuration = 30
        //picker.allowsEditing = true
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) { }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(assetPicker: self)
    }
    
    final class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate{
        
        let assetPicker : AssetPicker
        
        init (assetPicker: AssetPicker){
            self.assetPicker = assetPicker
        }
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let assetUrl = info[.imageURL] as? URL{
                assetPicker.api_wrapper.upload_image(imageUrl: assetUrl, imageManager: assetPicker.imageManager)//( paramName: "ParamName", fileName: "FileName", image: assetUrl )
            }
            else if let assetUrl = info[.mediaURL] as? URL{
                assetPicker.api_wrapper.upload_video(videoPath: assetUrl,videoManager: assetPicker.videoManager)
            }
            else{
                print("bad stuff")
            }
            picker.dismiss(animated: true)
        }
    }
}
