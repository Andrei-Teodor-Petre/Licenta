//
//  HomeController.swift
//  VSapp
//
//  Created by Andrei Petre on 05.04.2022.
//

import Foundation
import MobileCoreServices
import SwiftUI



//Pexels API key: 563492ad6f917000010000010216a365b01b4e928cc1fa618c5bc52d
//this is where the querry func will be




class VideoManager : ObservableObject{

    @Published private(set) var videos: [PexelsVideo] = []
    @Published private(set) var api_videos: [NetworkVideo] = []
    @Published private(set) var TagDictionary: [TagKey] = []
    
    private var api = APICaller()
    
    @Published var selctedQuery : TagKey = TagKey() {
        didSet{
            get_assets()
        }
    }
    
    init(){
        get_tags()
        get_assets()
    }
    
    func get_tags(){
        Task.init(){
            let result = await api.get_tags()
            TagDictionary = result
        }
    }

    
    func get_assets(){
//        Task.init(){
//            if(selctedQuery.value != "network"){
//                let result = await api.findVideos(topic: selctedQuery)
//
//                if(!result.isEmpty)
//                {
//                    DispatchQueue.main.async {
//                        self.videos = []
//                        self.api_videos = []
//                        self.videos = result
//                    }
//                }
//            }
//        }
        Task.init(){
            let result = await api.get_videos_library(tag: self.selctedQuery)
            if(!result.isEmpty)
            {
                DispatchQueue.main.async {
                    self.videos = []
                    self.api_videos = []
                    self.api_videos = result
                }
            }
        }
    }
    
    
    
}


class ImageManager : ObservableObject{
    @Published private(set) var images: [PexelsImage] = []
    @Published private(set) var network_images: [NetworkImage] = []
    private var api = APICaller()
    
    @Published var selctedQuery : TagKey = TagKey() {
        didSet{
            get_assets()
        }
    }
    
    init(){
        get_assets()
    }
    
    func get_assets(){
        Task.init(){
            if(selctedQuery.value != "network"){
                
                let result = await api.findImages(topic: selctedQuery)
                if(!result.isEmpty)
                {
                    DispatchQueue.main.async {
                        self.images = []
                        self.network_images = []
                        self.images = result
                    }
                }
            }

        }
        Task.init(){
            let result = await api.get_image_library()
            if(!result.isEmpty)
            {
                DispatchQueue.main.async {
                    self.images = []
                    self.network_images = []
                    self.network_images = result
                }
            }
        }
    }
}
