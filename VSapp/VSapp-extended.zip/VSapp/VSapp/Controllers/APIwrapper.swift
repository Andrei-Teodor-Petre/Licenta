//
//  APIwrapper.swift
//  VSapp
//
//  Created by Andrei Petre on 30.05.2022.
//

import Foundation
import UIKit
import Alamofire

struct APICaller {
    
    ///VIDEOS REGION
    
    func findVideos(topic: TagKey) async -> [PexelsVideo] {
        do {
            
            var searchParam = topic.value
            if searchParam == ""{
                searchParam = "nature"
            }
            guard let url = URL(string: "https://api.pexels.com/videos/search?query=\(searchParam)&per_page=100&orientation=portrait")
                else {fatalError("Missing URL")}
            var urlRequest = URLRequest(url: url)
            urlRequest.setValue("563492ad6f917000010000010216a365b01b4e928cc1fa618c5bc52d", forHTTPHeaderField: "Authorization")
            let (data, response) =  try await URLSession.shared.data(for: urlRequest);
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {fatalError("Error while fetching data")}
            
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let decodedData = try decoder.decode(ResponseBodyVideoSearchPexels.self, from: data)
            return decodedData.videos
            
        } catch{
            print("Error fetching videos data from pexels: \(error)")
        }
        return []
    }
    
    func get_tags() async -> [TagKey]{
        do {
            let stringUrl =  "\(constants.base_url)/get_tags"
            let urlRequest = URLRequest(url: URL(string: stringUrl)!)
            let (data, response) =  try await URLSession.shared.data(for: urlRequest);
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {fatalError("Error while fetching network data")}

                         
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let decodedData = try decoder.decode([TagKey].self, from: data)
            return decodedData
        } catch {
            print("Error fetching videos from the network: \(error)")
        }
        return []
    }
    
    func get_videos_library(tag: TagKey = TagKey()) async -> [NetworkVideo]{
        
        do {
            let stringUrl =  "\(constants.base_url)/get_videos/\(1)/\(String(tag.id))"
            let urlRequest = URLRequest(url: URL(string: stringUrl)!)
            let (data, response) =  try await URLSession.shared.data(for: urlRequest);
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {fatalError("Error while fetching network data")}

                         
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let decodedData = try decoder.decode([NetworkVideo].self, from: data)
            return decodedData
        } catch {
            print("Error fetching videos from the network: \(error)")
        }
        return []
    }
    
    func upload_video(videoPath: URL, videoManager: VideoManager = VideoManager()){
        var bodyKeyValue = [RequestBodyKeyValue]()
        bodyKeyValue.append(RequestBodyKeyValue(sKey: "a", sValue: "b", dBlobData: Data() ))
        let videoData = try! Data(contentsOf: videoPath)
        bodyKeyValue.append(RequestBodyKeyValue(sKey: "file", sValue: videoPath.lastPathComponent, dBlobData: videoData))
        
        let postUrl = "\(constants.base_url)/up_video"
        
        AF.upload(multipartFormData: { multipartFormData in
            for formData in bodyKeyValue{
                if(formData.dBlobData.isEmpty)
                {
                    multipartFormData.append(Data(formData.sValue.utf8), withName: formData.sKey )
                }
                else
                {
                    multipartFormData.append(Data(formData.dBlobData), withName: formData.sKey, fileName: formData.sValue, mimeType: "video/mov" )
                }
            }
        }, to: postUrl, method: .post)
        .uploadProgress{ progressValue in
            print(progressValue)
            if progressValue.isFinished{
                videoManager.get_assets()
            }
        }
        .response{ response in
            print(response)
        }
    }
    
    
    
    
    
    ///IMAGES REGION
    
    func findImages(topic: TagKey) async -> [PexelsImage]{
        do {
            //"https://api.pexels.com/v1/search?query=nature&per_page=1"
            var searchParam = topic.value
            if searchParam == ""{
                searchParam = "nature"
            }
            
            guard let url = URL(string: "https://api.pexels.com/v1/search?query=\(searchParam)&per_page=100&orientation=portrait")
                else {fatalError("Missing URL")}
            var urlRequest = URLRequest(url: url)
            urlRequest.setValue("563492ad6f917000010000010216a365b01b4e928cc1fa618c5bc52d", forHTTPHeaderField: "Authorization")
            let (data, response) =  try await URLSession.shared.data(for: urlRequest);
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {fatalError("Error while fetching data")}
            
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let decodedData = try decoder.decode(ResponseBodyImageSearchPexels.self, from: data)
            return decodedData.photos
        } catch{
            print("Error fetching images data from pexels: \(error)")
        }
        return []
    }
    
    func get_image_library() async -> [NetworkImage]{
        do {
            let stringUrl = constants.base_url + "/get_images"
            let urlRequest = URLRequest(url: URL(string: stringUrl)!)
            let (data, response) =  try await URLSession.shared.data(for: urlRequest);
            guard (response as? HTTPURLResponse)?.statusCode == 200 else {fatalError("Error while fetching data")}
            
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            let decodedData = try decoder.decode([NetworkImage].self, from: data)
            return decodedData
        } catch {
            print("Error fetching images from the network: \(error)")
        }
        return []
    }
    
    func upload_image(imageUrl: URL, imageManager: ImageManager = ImageManager()){
        
        var bodyKeyValue = [RequestBodyKeyValue]()
        bodyKeyValue.append(RequestBodyKeyValue(sKey: "a", sValue: "b", dBlobData: Data() ))
        let imageData = try! Data(contentsOf: imageUrl)
        bodyKeyValue.append(RequestBodyKeyValue(sKey: "file", sValue: imageUrl.lastPathComponent, dBlobData: imageData))

        let postUrl = "\(constants.base_url)/up_image"//"https://httpbin.org/post"
        
        AF.upload(multipartFormData: { multipartFormData in
            for formData in bodyKeyValue{
                if(formData.dBlobData.isEmpty)
                {
                    multipartFormData.append(Data(formData.sValue.utf8), withName: formData.sKey )
                }
                else
                {
                    multipartFormData.append(Data(formData.dBlobData), withName: formData.sKey, fileName: formData.sValue, mimeType: "image/jpeg" )
                }
            }
        }, to: postUrl, method: .post)
        .uploadProgress{ progressValue in
            //in case I need this upload value progress it's here
            print(progressValue)
            
            if progressValue.isFinished{
                imageManager.get_assets()
            }
        }
        .response{ response in
            print(response)
        }
    }
}

struct RequestBodyKeyValue {
    var sKey : String
    var sValue: String
    var dBlobData: Data
}


