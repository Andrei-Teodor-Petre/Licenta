//
//  VSappApp.swift
//  VSapp
//
//  Created by Andrei Petre on 05.04.2022.
//

import SwiftUI

@main

struct VSappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            //ConnectView()
        }
    }
}
